require 'rexml/document'
require 'transaction'
require 'yaml'

# Read in the YAML file and create an array of Transactions
transactions = YAML::load(File.read(ARGV[0]))
transactions.sort!
# Convert to an XML file that will be used by the mapping widget to display
# markers indicating charge locations.
doc = REXML::Document.new

root = doc.add_element("markers")
transactions.each do |trans|
  trans.update_coord if !trans.valid_coord?
  (root.elements << trans.to_xml) if trans.valid_coord?
end

doc.write($stdout, 0)