require 'net/http'
require 'rexml/element'

class Transaction
  attr_accessor :date, :name
  attr_reader :date, :city, :state
  
  # Maps between a "city,state" location string and a response from the geocoder.
  # Used to speed up the resolution of queries for the same location.
  @@cache = {}
  
  def set_location(city, state)
    @city = city
    @state = state
    update_coord
  end
  
  def update_coord
    @coord = Transaction.query_geocoder(@city, @state)
  end
  
  def valid_coord?
    coord != nil
  end
  
  def lat
    coord ? coord[0] : nil
  end
  
  def lng
    coord ? coord[1] : nil
  end
  
  def to_s
    "#{date}: #{name} - #{city},#{state} (#{lat}, #{lon})"
  end
  
  def to_xml
    el = REXML::Element.new("marker")
    el.attributes["lat"] = lat
    el.attributes["lng"] = lng
    el.attributes["date"] = date.to_i * 1000
    el.attributes["city"] = city
    el.attributes["state"] = state
    el.text = name
    
    el
  end

  def <=>(other_trans)
    date <=> other_trans.date
  end
  
  private
  attr_reader :coord

  # Returns a [lat,lng] array for the specified city, state or nil if the 
  # location is unknown.  
  def self.query_geocoder(city, state)
    location = "#{city},#{state}".gsub(/\s+/, "+")

    response = @@cache[location]
    unless response
      url = "http://maps.google.com/maps/geo?q=#{location}&output=csv&key=ABQIAAAAGOh9fVTmEs_59D6JX5GbqxR7IGsBxFpLtQs9l4zX2RXTLr9CNRSelYwjlAcg4RfTc28_4W3gq9QUfg"
      response = Net::HTTP.get_response(URI.parse(url)).body.split(/,/)
      @@cache[location] = response
    end
    
    # As per GMap docs, returned CSV string is: status code, accuracy, latitude, 
    # longitude
    if response[0] == "200"
      [response[2].to_f, response[3].to_f]
    else
      nil
    end
  end
end
