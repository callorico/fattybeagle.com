require 'time'
require 'yaml'
require 'transaction'

def parse_citi(contents)
  # Pull out the entire table row representing a single CC transaction.
  # There are several TR elements in the document but only transaction rows are
  # immediately followed by a < character.
  matches = contents.scan(/<TR VALIGN="TOP">(<.*?)<\/TR>/im).flatten

  matches.collect do |match|
    # Parse out the date and description fields from the transaction.  Every
    # field is tagged with the stmtdt1 class.
    fields = match.scan(/<TD CLASS="stmtdtl">(.*?)<\/TD>/).flatten
    trans = Transaction.new
    trans.date = Time.parse(fields[0])
    detail_match = fields[3].match(/(.{22}) (.*?)\s+([A-Z][A-Z]) $/)
    if detail_match
      trans.name = detail_match[1]
      trans.set_location(detail_match[2], detail_match[3])
    end
    
    trans
  end
end

def parse_chase(contents)
  
  matches = contents.scan(/^(\d\d\/\d\d).*?\d{23}(.*?)<br>/im)

  matches.collect do |match|
    trans = Transaction.new
    trans.date = Time.parse(match[0])
    
    # Extracting the city is problematic as there is no way to tell where the 
    # debitor's name ends and the city name begins.  Assume that no city name
    # is longer than 2 words.  Make an attempt to lookup the coordinates with
    # the rightmost word and state.  If this fails, try creating a city name
    # with 2 words.  Abort if any of the city words contain numbers.
    tokens = match[1].split(/\s+/)

    # The 2 letter state code is always the last token
    state = tokens.pop
    
    # Determine split point between the debitor name and the city name
    (tokens.length - 1).downto(tokens.length - 2) do |i| 
      trans.name = tokens[0..i - 1].join(" ")
      trans.set_location(tokens[i..tokens.length - 1].join(" "), state)
      # Bail on the loop if the computed city name is valid or the city name 
      # contains a number
      break if trans.valid_coord? || trans.city.match(/\d/) 
    end
    
    trans
  end
  
end


transactions = []

# TODO: arcane - Don't hardcode the file reading...
transactions.concat(parse_citi(File.read("citi/statements2.htm")))
transactions.concat(parse_citi(File.read("citi/statements.htm")))
transactions.concat(parse_chase(File.read("chase/JPMCStatements.html")))
transactions.concat(parse_chase(File.read("chase/JPMCStatement-2s.html")))

transactions.sort!

# Export transaction to an intermediate file that can be hand edited.
puts transactions.to_yaml